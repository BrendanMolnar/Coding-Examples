## 1. Preparing data for Analysis
# Importing required Libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

#Read csv file and store as a DataFrame named dv
df = pd.read_csv('Sales.csv')
print("The file loaded successfully")

#Print the dataframe
df.head()

#Print the shape of dataframe
df.shape

#Check for missing values
df.isnull().sum()

total_missing_values = df.isnull().sum().sum()
("Total missing values in the dataframe are : ", total_missing_values)

## 2. Normalize Data for Analysis
#Create a new DataFrame DF_data_only from Dataframe
df.head()
df.info()
df_data_only = df[['Unit', 'Sales']].copy()
df_data_only.head()

#Normalize the data
from sklearn.preprocessing import MinMaxScaler
scalar = MinMaxScaler()

normalize_data = scalar.fit_transform(df_data_only)
normalize_data_df = pd.DataFrame(normalize_data, columns =["Unit", "Sales"])
normalize_data_df.head()

normalize_data_df["Unit"].min(), normalize_data_df["Unit"].max()
normalize_data_df["Sales"].min(), normalize_data_df["Sales"].max()

print("Before Normalization")
print(df_data_only["Unit"].min(), df_data_only["Unit"].max())
print(df_data_only["Sales"].min(), df_data_only["Sales"].max())
print("After Normalization")
print(normalize_data_df["Unit"].min(), normalize_data_df["Unit"].max())
print(normalize_data_df["Sales"].min(), normalize_data_df["Sales"].max())

## 3. Visualize Overall Trend
#Convert Date column to dateline
df['Date'] = pd.to_datetime(df['Date'], format= "%d-%b-%y")
df.info()

#Group by the date and sum Unit and Sales
daily_data = df.groupby('Date')[["Unit", "Sales"]].sum().reset_index()
daily_data

plt.plot(daily_data['Date'], daily_data["Unit"], linewidth = 2, marker = "*")
plt.title("Date vs Unit Line Plot")
plt.xlabel("Date")
plt.ylabel("Unit")
plt.tick_params(axis = 'x', rotation = 45)
plt.show()

plt.plot(daily_data['Date'], daily_data["Sales"], linewidth = 2, marker = "*")
plt.title("Date vs Sales Line Plot")
plt.xlabel("Date")
plt.ylabel("Sales")
plt.tick_params(axis = 'x', rotation = 45)
plt.show()

## 4. Analyze Monthly Data
#Chunk Quarterly Data into Monthly Data
df_oct = df.loc[(df['Date'] >= '2020-10-1') & (df['Date'] < '2020-11-1')].copy()
df_oct.head()

df_nov = df.loc[(df['Date'] >= '2020-11-1') & (df['Date'] < '2020-12-1')].copy()
df_nov.head()

df_dec = df.loc[(df['Date'] >= '2020-12-1') & (df['Date'] < '2021-1-1')].copy()
df_dec.head()

print("Summary of Monthly Data")
print(f"Number of records in October : {len(df_oct)}")
print(f"Number of records in November : {len(df_nov)}")
print(f"Number of records in December : {len(df_dec)}")

## 5. Describe Data
#Describe entire dataset
df.describe(include = 'all')

#Description for October, November and December Data
df_oct[['Unit', 'Sales']].describe()
df_nov[['Unit', 'Sales']].describe()
df_dec[['Unit', 'Sales']].describe()

## 6. Analyze Unit Data
plt.boxplot(df_oct["Unit"])
plt.title("Unit distribution across October")
plt.show()

plt.boxplot(df_nov["Unit"])
plt.title("Unit distribution across November")
plt.show()

plt.boxplot(df_dec["Unit"])
plt.title("Unit distribution across December")
plt.show()

def extract_month_from_date(date):
    return date.strftime("%B")

date = df.loc[2750, "Date"]
df["Month"] = df["Date"].apply(extract_month_from_date)
df.head()

sns.boxplot(x="Month", y="Sales", data = df)
plt.title("Sales distribution across each Month")
plt.show()

## 7. Explore Monthly Plots and Analysis
#Overall Units and Sales Figures
print ("Unit Figures")
print (f"Total Units in October : {df_oct["Unit"].sum()}")
print (f"Total Units in November : {df_nov["Unit"].sum()}")
print (f"Total Units in December : {df_dec["Unit"].sum()}")

print ("Sales Figures")
print (f"Total Sales in October : {df_oct["Sales"].sum()}")
print (f"Total Sales in November : {df_nov["Sales"].sum()}")
print (f"Total Sales in December : {df_dec["Sales"].sum()}")

print ("Unit and Sales Figures")
print (f"Total Units Sold: {df["Unit"].sum()}")
print (f"Total Sales: {df["Sales"].sum()}")

df_oct_sales = df_oct.groupby("Date")["Sales"].sum().reset_index()
df_nov_sales = df_nov.groupby("Date")["Sales"].sum().reset_index()
df_dec_sales = df_dec.groupby("Date")["Sales"].sum().reset_index()
# Consolidated 3-Month Sales Plot
plt.figure(figsize = (15, 10))
plt.plot(df_oct_sales["Date"], df_oct_sales["Sales"], color = "g", marker = "*")
plt.title("Sales record in October")
plt.xlabel("Date")
plt.ylabel("Sales")
plt.show()

plt.figure(figsize = (15, 10))
plt.plot(df_nov_sales["Date"], df_nov_sales["Sales"], color = "g", marker = "*")
plt.title("Sales record in November")
plt.xlabel("Date")
plt.ylabel("Sales")
plt.show()

plt.figure(figsize = (15, 10))
plt.plot(df_dec_sales["Date"], df_dec_sales["Sales"], color = "g", marker = "*")
plt.title("Sales record in December")
plt.xlabel("Date")
plt.ylabel("Sales")
plt.show()

def extract_date_from_datetime(date):
    return date.strftime("%d")
df_oct["Day"] = df_oct["Date"].apply(extract_date_from_datetime)
df_oct_sale_daywide = df_oct.groupby("Day")["Sales"].sum().reset_index()
df_oct_sale_daywide.rename(columns = {"Sales" : "Oct Sales"}, inplace = True)

df_nov["Day"] = df_nov["Date"].apply(extract_date_from_datetime)
df_nov_sale_daywide = df_nov.groupby("Day")["Sales"].sum().reset_index()
df_nov_sale_daywide.rename(columns = {"Sales" : "Nov Sales"}, inplace = True)

df_dec["Day"] = df_dec["Date"].apply(extract_date_from_datetime)
df_dec_sale_daywide = df_dec.groupby("Day")["Sales"].sum().reset_index()
df_dec_sale_daywide.rename(columns = {"Sales" : "Dec Sales"}, inplace = True)

df_oct_sale_daywide.head()
df_nov_sale_daywide.head()
df_dec_sale_daywide.head()

plt.figure(figsize = (15, 10))
plt.plot(df_oct_sale_daywide["Day"], df_oct_sale_daywide["Oct Sales"], color = "g", marker = "*")
plt.plot(df_nov_sale_daywide["Day"], df_nov_sale_daywide["Nov Sales"], color = "b", marker = "*")
plt.plot(df_dec_sale_daywide["Day"], df_dec_sale_daywide["Dec Sales"], color = "r", marker = "*")
plt.title("Day Wide Sales")
plt.xlabel("Day")
plt.ylabel("Sales")
plt.show()

def extract_weekday_from_datetime(date):
    return date.strftime("%a")
df_oct["WeekDay"] = df_oct["Date"].apply(extract_weekday_from_datetime)
df_oct_sale_daywide = df_oct.groupby("Day")["Sales"].sum().reset_index()
df_oct_sale_daywide.rename(columns = {"Sales" : "Oct Sales"}, inplace = True)

df_nov["WeekDay"] = df_nov["Date"].apply(extract_weekday_from_datetime)
df_nov_sale_daywide = df_nov.groupby("Day")["Sales"].sum().reset_index()
df_nov_sale_daywide.rename(columns = {"Sales" : "Nov Sales"}, inplace = True)

df_dec["WeekDay"] = df_dec["Date"].apply(extract_weekday_from_datetime)
df_dec_sale_daywide = df_dec.groupby("Day")["Sales"].sum().reset_index()
df_dec_sale_daywide.rename(columns = {"Sales" : "Dec Sales"}, inplace = True)

df_oct_sale_daywide.head()
df_nov_sale_daywide.head()
df_dec_sale_daywide.head()

## 8. Obtain a Comprehensive Snapshot
#Overall Metrics
total_record = len(df)
total_units = df["Unit"].sum()
total_sales = df["Sales"].sum()
average_units = df["Unit"].mean()
average_sales = df["Sales"].mean()

print("Overall Metrics")
print(f"Total Records : {total_record}")
print(f"Total Units : {total_units}")
print(f"Total Sales : {total_sales}")
print(f"Average Units : {average_units}")
print(f"Average Sales : {average_sales}")

print("Overall Metrics for October")
print(f"Total Records : {len(df_oct)}")
print(f"Total Units : {df_oct["Unit"].sum()}")
print(f"Total Sales : {df_oct["Sales"].sum()}")
print(f"Average Units : {df_oct["Unit"].mean()}")
print(f"Average Sales : {df_oct["Sales"].mean()}")
print()
print("Overall Metrics for November")
print(f"Total Records : {len(df_nov)}")
print(f"Total Units : {df_nov["Unit"].sum()}")
print(f"Total Sales : {df_nov["Sales"].sum()}")
print(f"Average Units : {df_nov["Unit"].mean()}")
print(f"Average Sales : {df_nov["Sales"].mean()}")
print()
print("Overall Metrics for December")
print(f"Total Records : {len(df_dec)}")
print(f"Total Units : {df_dec["Unit"].sum()}")
print(f"Total Sales : {df_dec["Sales"].sum()}")
print(f"Average Units : {df_dec["Unit"].mean()}")
print(f"Average Sales : {df_dec["Sales"].mean()}")

## 9. Analyze Statewide Sales
df["State"].unique()
state_wide_data = df.groupby("State")[["Unit", "Sales"]].sum().reset_index()
state_wide_data

plt.bar(state_wide_data["State"], state_wide_data["Unit"])
plt.title("State Wide Sales")
plt.xlabel("State")
plt.ylabel("Unit")
plt.show()

plt.bar(state_wide_data["State"], state_wide_data["Sales"])
plt.title("State Wide Sales")
plt.xlabel("State")
plt.ylabel("Sales")
plt.show()

